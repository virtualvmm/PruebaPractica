<?php
// modelo/ComunidadModelo.php

class ComunidadModelo {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function insertarComunidad($nombre, $direccion, $poblacion, $idAdministrador) {
        $query = "INSERT INTO Comunidades (Nombre, Dirección, Población, id_administrador) VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);

        if ($stmt === false) {
            die('Error preparando la consulta: ' . $this->db->error);
        }

        $stmt->bind_param("sssi", $nombre, $direccion, $poblacion, $idAdministrador);
        if ($stmt->execute()) {
            return $this->db->insert_id;
        } else {
            die('Error ejecutando la consulta: ' . $stmt->error);
        }
    }
}
?>
