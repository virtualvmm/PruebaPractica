<?php
// index.php

require_once 'config.php';
require_once 'modelo/ComunidadModelo.php';
require_once 'vistas/ComunidadVistas.php';
require_once 'controlador/ComunidadControlador.php';

// Crear instancias del modelo, vista y controlador
$modelo = new ComunidadModelo($mysqli);
$vista = new ComunidadVistas();
$controlador = new ComunidadControlador($modelo, $vista);

// Manejar la solicitud
$controlador->manejarSolicitud();

$mysqli->close();
?>
