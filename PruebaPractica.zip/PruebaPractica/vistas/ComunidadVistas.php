<?php
// vistas/ComunidadVistas.php

class ComunidadVistas {
    public function mostrarFormulario() {
        echo '<form method="post" action="">
                Nombre: <input type="text" name="nombre" required><br>
                Dirección: <input type="text" name="direccion" required><br>
                Población: <input type="text" name="poblacion" required><br>
                ID Administrador: <input type="number" name="id_administrador" required><br>
                <input type="submit" value="Añadir Comunidad">
              </form>';
    }

    public function mostrarResultado($mensaje) {
        echo $mensaje;
    }
}
?>
