<?php
// config.php

$host = 'localhost';
$usuario = 'root';
$contraseña = '';
$baseDeDatos = 'pruebapractica';

$mysqli = new mysqli($host, $usuario, $contraseña, $baseDeDatos);

if ($mysqli->connect_error) {
    die('Error de conexión (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}
?>
