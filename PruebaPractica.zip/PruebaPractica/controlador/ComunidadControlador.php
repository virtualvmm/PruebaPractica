<?php
// controlador/ComunidadControlador.php

class ComunidadControlador {
    private $modelo;
    private $vista;

    public function __construct($modelo, $vista) {
        $this->modelo = $modelo;
        $this->vista = $vista;
    }

    public function manejarSolicitud() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'];
            $direccion = $_POST['direccion'];
            $poblacion = $_POST['poblacion'];
            $idAdministrador = $_POST['id_administrador'];

            $id = $this->modelo->insertarComunidad($nombre, $direccion, $poblacion, $idAdministrador);
            if ($id) {
                $this->vista->mostrarResultado("Comunidad añadida con éxito. ID: $id");
            } else {
                $this->vista->mostrarResultado("Error al añadir la comunidad.");
            }
        } else {
            $this->vista->mostrarFormulario();
        }
    }
}
?>
